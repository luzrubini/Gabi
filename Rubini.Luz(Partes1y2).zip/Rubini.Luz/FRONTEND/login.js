"use strict";
/// <reference path="../node_modules/@types/jquery/index.d.ts" />
$(document).ready(function () {
    Login.CargarUsuarios();
    $("#btnEnviarLogin").click(function (e) {
        e.preventDefault();
        Login.Login();
    });
    $("#btnEnviar").click(function (e) {
        e.preventDefault();
        Login.Registrar();
    });
    localStorage.removeItem("usuarioActual");
    localStorage.removeItem("token");
});
var Login = /** @class */ (function () {
    function Login() {
    }
    Login.Login = function () {
        var correo = $("#mailLogin").val();
        var clave = $("#passwordLogin").val();
        var datos = {
            correo: correo,
            clave: clave
        };
        var formData = new FormData();
        formData.append("datos", JSON.stringify(datos));
        $.ajax({
            type: "POST",
            url: "./BACKEND/login/",
            dataType: "json",
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            async: true
        })
            .done(function (response) {
            if (response.exito) {
                localStorage.setItem("token", response.jwt);
                $("#loginForm").trigger("reset");
                for (var _i = 0, _a = JSON.parse(localStorage.getItem("usuarios")); _i < _a.length; _i++) {
                    var user = _a[_i];
                    if (user.correo === correo) {
                        localStorage.setItem('usuarioActual', JSON.stringify(user));
                        break;
                    }
                }
                location.assign("principal.html");
            }
        })
            .fail(function (jqXHR) {
            Login.ManejoAlert(JSON.parse(jqXHR.responseText).msg, "alert-warning");
        });
    };
    Login.ManejoAlert = function (msg, tipoAlert) {
        $("#msg").html(msg);
        $("#alert").addClass(tipoAlert);
        $("#alert").removeClass("hidden");
        $("#alert").addClass("show");
        setInterval(function () {
            $("#alert").addClass("hidden");
            $("#alert").removeClass("show");
            $("#alert").removeClass(tipoAlert);
        }, 5000);
    };
    Login.CargarUsuarios = function () {
        $.ajax({
            type: "GET",
            url: "./BACKEND/",
            dataType: "json",
            cache: false,
            contentType: false,
            processData: false,
            async: true
        })
            .done(function (response) {
            if (response.exito) {
                localStorage.removeItem('usuarios');
                localStorage.setItem("usuarios", JSON.stringify(response.usuarios));
            }
        })
            .fail(function (jqXHR, textStatus, errorThrown) {
            Login.ManejoAlert(JSON.parse(jqXHR.responseText).msg, "alert-warning");
            localStorage.removeItem('usuarios');
        });
    };
    Login.Registrar = function () {
        var nombre = $("#nombre").val();
        var apellido = $("#apellido").val();
        var correo = $("#mail").val();
        var clave = $("#password").val();
        var perfil = $("#perfil").val();
        var foto = $("#foto")[0];
        var usuario = {
            nombre: nombre,
            apellido: apellido,
            correo: correo,
            perfil: perfil,
            clave: clave
        };
        var formData = new FormData();
        formData.append("datos", JSON.stringify(usuario));
        formData.append("foto", foto.files[0]);
        $.ajax({
            type: "POST",
            url: "./BACKEND/usuarios/",
            dataType: "json",
            cache: false,
            data: formData,
            contentType: false,
            processData: false,
            async: true
        })
            .done(function (response) {
            if (response.exito == true) {
                Login.ManejoAlert(response.msg, "alert-success");
                $("#registroForm").trigger("reset");
                location.assign("./login.html");
            }
            else {
                Login.ManejoAlert(response.msg, "alert-danger");
            }
        })
            .fail(function (jqXHR) {
            Login.ManejoAlert(JSON.parse(jqXHR.responseText).msg, "alert-warning");
        });
    };
    return Login;
}());
//# sourceMappingURL=login.js.map