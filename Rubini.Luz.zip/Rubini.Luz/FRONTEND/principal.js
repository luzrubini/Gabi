"use strict";
/// <reference path="../node_modules/@types/jquery/index.d.ts" />
var Principal = /** @class */ (function () {
    function Principal() {
    }
    Principal.Verificar = function () {
        var token = localStorage.getItem("token");
        $.ajax({
            type: "GET",
            url: "./BACKEND/login/",
            headers: { token: token },
            dataType: "json",
            cache: false,
            contentType: false,
            processData: false,
            async: true
        })
            .done(function (response) {
            //Principal.ManejoAlert(response.msg, "alert-success");
        })
            .fail(function (jqXHR) {
            Principal.ManejoAlert(JSON.parse(jqXHR.responseText).msg, "alert-warning");
            location.assign("login.html");
        });
    };
    Principal.ManejoAlert = function (msg, tipoAlert) {
        $("#msg").html(msg);
        $("#alert").addClass(tipoAlert);
        $("#alert").removeClass("hidden");
        $("#alert").addClass("show");
        setInterval(function () {
            $("#alert").addClass("hidden");
            $("#alert").removeClass("show");
            $("#alert").removeClass(tipoAlert);
        }, 5000);
    };
    Principal.ArmarTabla = function () {
        var userActual = JSON.parse(localStorage.getItem('usuarioActual'));
        var listaString = " <div class=\"table-responsive\">\n        <table class=\"table table-striped\" id=\"tablaUsers\">\n            <thead>\n                <th>ID</th>\n                <th>Correo</th>\n                <th>Nombre</th>\n                <th>Apellido</th>\n                <th>Perfil</th>\n                <th>Foto</th>";
        listaString += "</thead><tbody>";
        for (var _i = 0, _a = JSON.parse(localStorage.getItem('usuarios')); _i < _a.length; _i++) {
            var user = _a[_i];
            listaString += "<tr>\n            <td>" + user.id + "</td>\n            <td>" + user.correo + "</td>\n            <td>" + user.nombre + "</td>\n            <td>" + user.apellido + "</td>\n            <td>" + user.perfil + ("</td>\n            <td><img src=" + user.foto + " height=\"50px\" width=\"50px\"></td>");
            listaString += "</tr>";
        }
        listaString += "</tbody></table></div>";
        $('#tabla').html(listaString);
        if (userActual.perfil === "empleado") {
            $("#tablaUsers tbody tr").each(function () {
                $(this).children("td").each(function () {
                    $(this).children('img').addClass('img-rounded');
                });
            });
        }
        if (userActual.perfil === "encargado") {
            $("#tablaUsers tbody tr").each(function () {
                $(this).children("td").each(function () {
                    $(this).children('img').addClass('img-thumbnail');
                });
            });
        }
    };
    Principal.ArmarTablaAutos = function () {
        var userActual = JSON.parse(localStorage.getItem('usuarioActual'));
        var listaString = " <div class=\"table-responsive\">\n        <table class=\"table table-condensed\" id=\"tablaAutos\">\n            <thead>\n                <th>ID</th>\n                <th>Color</th>\n                <th>Marca</th>\n                <th>Precio</th>\n                <th>Modelo</th>";
        if (userActual.perfil === "propietario") {
            listaString += "<th>Acciones</th>";
        }
        listaString += "</thead><tbody>";
        for (var _i = 0, _a = JSON.parse(localStorage.getItem('autos')); _i < _a.length; _i++) {
            var auto = _a[_i];
            listaString += "<tr>\n            <td>" + auto.id + "</td>\n            <td>" + auto.color + "</td>\n            <td>" + auto.marca + "</td>\n            <td>" + auto.precio + "</td>\n            <td>" + auto.modelo + "</td>";
            switch (userActual.perfil) {
                case "propietario": {
                    listaString += "<td><button type=\"button\" class=\"btn btn-danger\" onclick='Principal.EliminarAuto(" + JSON.stringify(auto) + ")' data-toggle=\"modal\" data-target=\"#eliminarAuto\">Eliminar</button></td>";
                    listaString += "<td><button type=\"button\" class=\"btn btn-warning\" onclick='Principal.Modificar(" + JSON.stringify(auto) + ")' data-toggle=\"modal\" data-target=\"#modificacionAuto\">Modificar</button></td>";
                    break;
                }
                case "encargado": {
                    listaString += "<td><button type=\"button\" class=\"btn btn-warning\" onclick='Principal.Modificar(" + JSON.stringify(auto) + ")' data-toggle=\"modal\" data-target=\"#modificacionAuto\">Modificar</button></td>";
                    break;
                }
                default:
                    break;
            }
            listaString += "</tr>";
        }
        listaString += "</tbody></table></div>";
        $('#tablaAutos').html(listaString);
    };
    Principal.CargarAutos = function () {
        $.ajax({
            type: "GET",
            url: "./BACKEND/autos/",
            dataType: "json",
            cache: false,
            contentType: false,
            processData: false,
            async: true
        })
            .done(function (response) {
            if (response.exito) {
                localStorage.setItem("autos", JSON.stringify(response.autos));
                Principal.ArmarTablaAutos();
            }
        })
            .fail(function (jqXHR, textStatus, errorThrown) {
            Principal.ManejoAlert(JSON.parse(jqXHR.responseText).msg, "alert-warning");
        });
    };
    Principal.CargarUsuarios = function () {
        $.ajax({
            type: "GET",
            url: "./BACKEND/",
            dataType: "json",
            cache: false,
            contentType: false,
            processData: false,
            async: true
        })
            .done(function (response) {
            if (response.exito) {
                localStorage.setItem("usuarios", JSON.stringify(response.usuarios));
                Principal.ArmarTabla();
            }
        })
            .fail(function (jqXHR, textStatus, errorThrown) {
            Principal.ManejoAlert(JSON.parse(jqXHR.responseText).msg, "alert-warning");
        });
    };
    Principal.EliminarAuto = function (auto) {
        $("#confirmarTextoAuto").html("Desea eliminar el auto con modelo " + auto.modelo + "?");
        $("#modal-btn-si-Auto").off('click').on("click", function () {
            $.ajax({
                method: "DELETE",
                url: "./BACKEND/",
                data: { "id": auto.id },
                headers: { "token": localStorage.getItem("token") },
                async: true
            })
                .done(function (response) {
                if (response.exito) {
                    Principal.CargarAutos();
                    Principal.ManejoAlert(response.msg, "alert-success");
                }
                else {
                    Principal.ManejoAlert(response.msg, "alert-danger");
                }
            })
                .fail(function (jqXHR, textStatus, errorThrown) {
                Principal.ManejoAlert(JSON.parse(jqXHR.responseText).msg, "alert-warning");
                location.assign("./login.html");
            });
        });
    };
    Principal.Modificar = function (obj) {
        $("#marca").val(obj.marca);
        $("#color").val(obj.color);
        $("#precio").val(obj.precio);
        $("#modelo").val(obj.modelo);
        $("#id").val(obj.id);
        $("#autoForm").off('submit').submit(function (event) {
            event.preventDefault();
            Principal.verificarModificacion();
        });
    };
    Principal.verificarModificacion = function () {
        var marca = $("#marca").val();
        var color = $("#color").val();
        var precio = $("#precio").val();
        var modelo = $("#modelo").val();
        var id = $("#id").val();
        var auto = {
            id: id,
            marca: marca,
            color: color,
            precio: precio,
            modelo: modelo
        };
        var formData = new FormData();
        formData.append("datos", JSON.stringify(auto));
        $("#btnEnviar").off('click').on("click", function () {
            $.ajax({
                method: "POST",
                url: "./BACKEND/modificar",
                data: formData,
                contentType: false,
                processData: false,
                headers: { "token": localStorage.getItem("token") }
            })
                .done(function (response) {
                if (response.exito == true) {
                    Principal.CargarAutos();
                    $("#modificacionAuto").modal("hide");
                    Principal.ManejoAlert(response.msg, "alert-success");
                }
                else {
                    Principal.ManejoAlert(response.msg, "alert-danger");
                }
            })
                .fail(function (jqXHR, textStatus, errorThrown) {
                alert(jqXHR.responseText + textStatus + errorThrown);
                Principal.ManejoAlert(JSON.parse(jqXHR.responseText).msg, "alert-warning");
            });
        });
    };
    return Principal;
}());
$(document).ready(function () {
    Principal.CargarUsuarios();
    Principal.CargarAutos();
    if (!localStorage.getItem("token")) {
        location.assign("login.html");
    }
    else {
        Principal.Verificar();
    }
});
//# sourceMappingURL=principal.js.map